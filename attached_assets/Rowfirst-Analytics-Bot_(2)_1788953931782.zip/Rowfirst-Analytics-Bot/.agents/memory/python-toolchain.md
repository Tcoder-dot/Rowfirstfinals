---
name: Python package environment
description: Environment constraint for installing Python dependencies in this project.
---

Install Python dependencies through the managed Python toolchain rather than the system interpreter. The system interpreter is externally managed and rejects package installation, while the project toolchain provides pip and installs into the project environment.

**Why:** The repository's requirements install failed under the system Python because of the environment's PEP 668 protection.

**How to apply:** Before installing this project's Python requirements in a fresh environment, ensure the managed Python toolchain is available, then install the packages through that toolchain.